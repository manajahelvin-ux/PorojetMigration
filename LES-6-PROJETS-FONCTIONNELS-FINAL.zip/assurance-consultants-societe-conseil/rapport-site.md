# Rapport de conversion — `assurance-consultants-societe-conseil`

- **Page source** : `assurance-consultants-societe-conseil.html` (dépot GitHub, export Webflow)
- **Domaine cible** : https://assurance-consultants-societe-conseil.lp.comparateurpro.fr
- **Date** : 2026-10-22

## Résultat
| Indicateur | Valeur |
|---|---|
| Fichiers totaux | 79 |
| Poids total | 7.89 Mo |
| Images rapatriées | 0 |
| Polices rapatriées | 0 |
| CSS finale | 176 Ko |
| JS finale | 1475 Ko |
| Assets introuvables | 0 |

## SEO
- H1 : **0** ⚠ à corriger (0 ou plusieurs)
- GTM : GTM-53SH7D7F
- Éléments ajoutés automatiquement : meta description (reprise de og:description), canonical
- Liens vers d'autres pages du dépôt (à trancher) : aucun

## Hôtes externes encore appelés par la page
assurance-consultants-societe-conseil.lp.comparateurpro.fr, www.googletagmanager.com, www.hellolead.pro

## ⚠ Avertissements
- 2 @font-face cassée(s) (src .zip / format "undefined" — bug d'export Webflow) retirée(s) ; la police retombe sur sa pile système de secours

## Checklist QA humaine avant mise en ligne
1. Comparaison visuelle côte à côte avec la page Webflow d'origine.
2. Parcours complet du formulaire (toutes les étapes, champs obligatoires, erreurs).
3. Test OTP SMS avec un numéro de test.
4. Vérification de la réception du lead en CRM / Google Sheets.
5. Tag Assistant : déclenchement GTM et de l'événement `formulaire_lead`.
6. Lighthouse mobile : performance et accessibilité.
7. Relire meta description (générée automatiquement) et titre.

_Généré par lp2site.py_