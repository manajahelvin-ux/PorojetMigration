# Rapport de conversion — `assurance-consultant-societe-conseil-v2`

- **Page source** : `assurance-consultant-societe-conseil-v2.html` (dépot GitHub, export Webflow)
- **Domaine cible** : https://assurance-consultant-societe-conseil-v2.lp.comparateurpro.fr
- **Date** : 2026-10-22

## Résultat
| Indicateur | Valeur |
|---|---|
| Fichiers totaux | 40 |
| Poids total | 5.56 Mo |
| Images rapatriées | 0 |
| Polices rapatriées | 0 |
| CSS finale | 139 Ko |
| JS finale | 1457 Ko |
| Assets introuvables | 0 |

## SEO
- H1 : **0** ⚠ à corriger (0 ou plusieurs)
- GTM : absent
- Éléments ajoutés automatiquement : meta description (auto — à relire), canonical
- Liens vers d'autres pages du dépôt (à trancher) : aucun

## Hôtes externes encore appelés par la page
assurance-consultant-societe-conseil-v2.lp.comparateurpro.fr, www.ubepro.com

## ⚠ Avertissements
- 2 @font-face cassée(s) (src .zip / format "undefined" — bug d'export Webflow) retirée(s) ; la police retombe sur sa pile système de secours

## Checklist QA humaine avant mise en ligne
1. Comparaison visuelle côte à côte avec la page Webflow d'origine.
2. Parcours complet du formulaire (toutes les étapes, champs obligatoires, erreurs).
3. Test OTP SMS avec un numéro de test.
4. Vérification de la réception du lead en CRM / Google Sheets.
5. Tag Assistant : déclenchement GTM et de l'événement `formulaire_lead`.
6. Lighthouse mobile : performance et accessibilité.
7. Relire meta description (générée automatiquement) et titre.

_Généré par lp2site.py_